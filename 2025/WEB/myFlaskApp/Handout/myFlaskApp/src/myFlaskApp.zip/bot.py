from playwright.sync_api import sync_playwright
import os

def visit(url):
    # Get environment variables
    admin_password = os.getenv("ADMIN_PASSWORD", "admin")
    flag = os.getenv("FLAG", "bi0sctf{testflag}")

    with sync_playwright() as p:
        # Configure browser with same options as Selenium
        browser = p.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu"
            ]
        )
        page = browser.new_page()

        try:
            # Navigate to login page
            page.goto("http://localhost:5000/login", wait_until="networkidle")
            page.wait_for_timeout(1000)  # Wait 1 second as in Selenium

            # Fill out the login form
            page.fill("#username", "admin")
            page.fill("#password", admin_password)
            page.click("button[type='submit']")
            print("Logged in as admin")

            # Wait for login to complete
            page.wait_for_timeout(1000)  # Wait 1 second as in Selenium

            # Add cookie
            page.context.add_cookies([{
                'name': 'flag',
                'value': flag,
                'domain': 'localhost',
                'path': '/',
                'httpOnly': False,
                'sameSite': 'Lax',
                'secure': False
            }])

            # Visit the provided URL
            print(f"Visiting URL: {url}")
            page.goto(url, wait_until="networkidle")
            page.wait_for_timeout(3000)  # Wait 3 seconds as in Selenium

        except Exception as e:
            print(f"Bot error: {str(e)}")
        finally:
            browser.close()