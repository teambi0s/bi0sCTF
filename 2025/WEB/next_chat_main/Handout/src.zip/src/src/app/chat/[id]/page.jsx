"use client";

export default function ChatPage() {
  return null;
}