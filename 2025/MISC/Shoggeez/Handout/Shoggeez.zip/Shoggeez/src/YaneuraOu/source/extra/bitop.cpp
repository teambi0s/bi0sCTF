#include "../types.h"
#include "bitop.h"

ymm ymm_zero = ymm(uint8_t(0));
ymm ymm_one = ymm(uint8_t(1));
